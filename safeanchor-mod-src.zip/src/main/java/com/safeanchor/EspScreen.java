package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Menu rieng cho ESP (mo tu nut "ESP Settings" trong menu chinh). */
public class EspScreen extends Screen {
    private final Screen parent;

    public EspScreen(Screen parent) {
        super(Text.literal("ESP"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.INSTANCE;
        int colW = 150, gap = 8, rowH = 22, rows = 8;
        int left = this.width / 2 - colW - gap / 2;
        int right = this.width / 2 + gap / 2;
        int top = Math.max(24, this.height / 2 - (rows * rowH) / 2 - 4);

        addDrawableChild(ConfigScreen.toggle("ESP", () -> c.esp, v -> c.esp = v, left, top, colW));
        addDrawableChild(modeButton(right, top, colW));

        addDrawableChild(ConfigScreen.toggle("Players", () -> c.espPlayers, v -> c.espPlayers = v, left, top + rowH, colW));
        addDrawableChild(colorButton("Players", () -> c.espPlayerColor, v -> c.espPlayerColor = v, right, top + rowH, colW));

        addDrawableChild(ConfigScreen.toggle("Mobs", () -> c.espMobs, v -> c.espMobs = v, left, top + rowH * 2, colW));
        addDrawableChild(colorButton("Mobs", () -> c.espMobColor, v -> c.espMobColor = v, right, top + rowH * 2, colW));

        addDrawableChild(ConfigScreen.toggle("Storage", () -> c.espStorage, v -> c.espStorage = v, left, top + rowH * 3, colW));
        addDrawableChild(colorButton("Chest", () -> c.espChestColor, v -> c.espChestColor = v, right, top + rowH * 3, colW));

        addDrawableChild(ConfigScreen.toggle("Tracers", () -> c.espTracers, v -> c.espTracers = v, left, top + rowH * 4, colW));
        addDrawableChild(colorButton("Ender", () -> c.espEnderColor, v -> c.espEnderColor = v, right, top + rowH * 4, colW));

        addDrawableChild(new ConfigScreen.ConfigSlider(left, top + rowH * 5, colW, 20, "Thickness", 1, 6, 0.5,
                c.espThickness, v -> c.espThickness = v));
        addDrawableChild(colorButton("Shulker", () -> c.espShulkerColor, v -> c.espShulkerColor = v, right, top + rowH * 5, colW));

        addDrawableChild(new ConfigScreen.ConfigSlider(left, top + rowH * 6, colW, 20, "Fill Alpha", 10, 255, 5,
                c.espAlpha, v -> c.espAlpha = (int) Math.round(v)));
        addDrawableChild(new ConfigScreen.ConfigSlider(right, top + rowH * 6, colW, 20, "Range", 16, 256, 8,
                c.espRange, v -> c.espRange = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 - 100, top + rowH * 7 + 4, 200, 20).build());
    }

    private static ButtonWidget modeButton(int x, int y, int w) {
        return ButtonWidget.builder(modeText(), b -> {
            Config.INSTANCE.espMode = (Math.floorMod(Config.INSTANCE.espMode, Esp.MODES.length) + 1) % Esp.MODES.length;
            b.setMessage(modeText());
        }).dimensions(x, y, w, 20).build();
    }

    private static Text modeText() {
        return Text.literal("Mode: " + Esp.MODES[Math.floorMod(Config.INSTANCE.espMode, Esp.MODES.length)]);
    }

    static ButtonWidget colorButton(String label, IntSupplier get, IntConsumer set, int x, int y, int w) {
        return ButtonWidget.builder(colorText(label, get.getAsInt()), b -> {
            int i = Esp.indexOf(get.getAsInt());
            set.accept(Esp.COLORS[(i + 1) % Esp.COLORS.length]);
            b.setMessage(colorText(label, get.getAsInt()));
        }).dimensions(x, y, w, 20).build();
    }

    private static Text colorText(String label, int rgb) {
        int i = Esp.indexOf(rgb);
        String name = i >= 0 ? Esp.COLOR_NAMES[i] : String.format(Locale.ROOT, "#%06X", rgb & 0xFFFFFF);
        return Text.literal(label + ": ").append(Text.literal(name).styled(st -> st.withColor(rgb)));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public void removed() {
        Config.save();
    }
}
