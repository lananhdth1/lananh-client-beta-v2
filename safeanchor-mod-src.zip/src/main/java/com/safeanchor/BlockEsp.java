package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Block ESP: quet chunk quanh ban (tung chunk 1 luot de khong giat), nho vi tri cac block
 * nam trong danh sach, roi Esp.render ve vien/to mau xuyen tuong.
 */
public class BlockEsp {
    public static final String[] ORES = {
            "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore", "minecraft:ancient_debris",
            "minecraft:emerald_ore", "minecraft:deepslate_emerald_ore"};
    public static final String[] UTILITY = {
            "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker",
            "minecraft:hopper", "minecraft:dispenser", "minecraft:dropper"};
    public static final String[] SPECIAL = {
            "minecraft:beacon", "minecraft:spawner", "minecraft:trial_spawner"};

    private static final int MAX_TARGETS = 3000;

    private record Hit(int x, int y, int z, int rgb) {}
    private static final class Entry {
        final int cx, cz;
        final List<Hit> hits;
        Entry(int cx, int cz, List<Hit> hits) { this.cx = cx; this.cz = cz; this.hits = hits; }
    }

    private static final Map<Long, Entry> CACHE = new HashMap<>();
    private static final ArrayDeque<int[]> QUEUE = new ArrayDeque<>();
    private static Map<Block, Integer> wanted = new HashMap<>();
    private static int sig = 0;

    private static int signature(Config c) {
        return Objects.hash(c.espBlkOres, c.espBlkUtility, c.espBlkSpecial,
                c.espBlkOreColor, c.espBlkUtilityColor, c.espBlkSpecialColor, c.espBlkCustomColor,
                c.espBlkCustom);
    }

    private static void rebuild(Config c) {
        Map<Block, Integer> m = new HashMap<>();
        if (c.espBlkOres) add(m, List.of(ORES), c.espBlkOreColor);
        if (c.espBlkUtility) add(m, List.of(UTILITY), c.espBlkUtilityColor);
        if (c.espBlkSpecial) add(m, List.of(SPECIAL), c.espBlkSpecialColor);
        add(m, c.espBlkCustom, c.espBlkCustomColor);
        wanted = m;
    }

    private static void add(Map<Block, Integer> m, List<String> ids, int rgb) {
        for (String s : ids) {
            Identifier id = Identifier.tryParse(s);
            if (id == null || !Registries.BLOCK.containsId(id)) continue;
            Block b = Registries.BLOCK.get(id);
            if (b != Blocks.AIR) m.put(b, rgb);
        }
    }

    private static long key(int cx, int cz) {
        return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL);
    }

    public static void tick(MinecraftClient mc) {
        Config cfg = Config.INSTANCE;
        if (!cfg.enabled || !cfg.espBlocks || mc.player == null || mc.world == null) {
            if (!CACHE.isEmpty()) CACHE.clear();
            QUEUE.clear();
            sig = 0;
            return;
        }
        int s = signature(cfg);
        if (s != sig) {
            sig = s;
            rebuild(cfg);
            CACHE.clear();
            QUEUE.clear();
        }
        if (wanted.isEmpty()) return;

        int r = Math.max(1, Math.min(8, (int) Math.ceil(cfg.espBlkRange / 16.0)));
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        if (QUEUE.isEmpty()) {
            List<int[]> list = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) list.add(new int[]{pcx + dx, pcz + dz});
            list.sort(Comparator.comparingInt(a -> (a[0] - pcx) * (a[0] - pcx) + (a[1] - pcz) * (a[1] - pcz)));
            QUEUE.addAll(list);
            CACHE.values().removeIf(e -> Math.abs(e.cx - pcx) > r + 1 || Math.abs(e.cz - pcz) > r + 1);
        }

        int perTick = r > 4 ? 1 : 2;
        for (int n = 0; n < perTick; n++) {
            int[] c = QUEUE.poll();
            if (c == null) break;
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(c[0], c[1]);
            if (chunk == null) { CACHE.remove(key(c[0], c[1])); continue; }
            CACHE.put(key(c[0], c[1]), new Entry(c[0], c[1], scan(chunk, c[0], c[1])));
        }
    }

    private static List<Hit> scan(WorldChunk chunk, int cx, int cz) {
        List<Hit> out = new ArrayList<>();
        int baseX = cx << 4, baseZ = cz << 4, bottom = chunk.getBottomY();
        ChunkSection[] sections = chunk.getSectionArray();
        for (int si = 0; si < sections.length; si++) {
            ChunkSection sec = sections[si];
            if (sec == null || sec.isEmpty()) continue;
            int baseY = bottom + si * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        Integer rgb = wanted.get(sec.getBlockState(x, y, z).getBlock());
                        if (rgb != null) out.add(new Hit(baseX + x, baseY + y, baseZ + z, rgb));
                    }
                }
            }
        }
        return out;
    }

    /** Duoc Esp.render goi: them cac block da quet vao danh sach ve. */
    static void collect(List<Esp.Target> out, MinecraftClient mc) {
        if (wanted.isEmpty() || mc.world == null || mc.player == null) return;
        double range = Math.max(8.0, Config.INSTANCE.espBlkRange);
        double r2 = range * range;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        int added = 0;
        for (Entry e : CACHE.values()) {
            for (Hit h : e.hits) {
                if (mc.player.squaredDistanceTo(h.x() + 0.5, h.y() + 0.5, h.z() + 0.5) > r2) continue;
                mp.set(h.x(), h.y(), h.z());
                if (!wanted.containsKey(mc.world.getBlockState(mp).getBlock())) continue; // da bi dao / doi
                out.add(new Esp.Target(new Box(h.x(), h.y(), h.z(), h.x() + 1, h.y() + 1, h.z() + 1), h.rgb(), false));
                if (++added >= MAX_TARGETS) return;
            }
        }
    }
}
