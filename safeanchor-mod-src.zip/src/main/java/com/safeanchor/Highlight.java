package com.safeanchor;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

/**
 * Lam sang (vien mau) block pearl se roi xuong va doi thu dang nhin vao.
 * Tat ca dung chung 1 mau, chon trong menu.
 */
public class Highlight {
    public static final String[] NAMES = {"Lime", "Magenta", "Cyan", "Yellow", "Red", "White"};
    public static final int[] RGB = {0x00FF00, 0xFF00FF, 0x00FFFF, 0xFFFF00, 0xFF0000, 0xFFFFFF};

    private static final BufferAllocator ALLOC = new BufferAllocator(8192);
    private static final VertexConsumerProvider.Immediate IMM = VertexConsumerProvider.immediate(ALLOC);

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config cfg = Config.INSTANCE;
        if (!cfg.enabled || !cfg.highlight || mc.player == null || mc.world == null) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        BlockPos landBlock = null;
        Box landBox = null;
        Box lookBox = null;

        // 1) Cam pearl -> noi pearl se roi
        if (cfg.pearlLanding && holdingPearl(mc)) {
            BlockPos[] ob = new BlockPos[1];
            Box[] oe = new Box[1];
            simulatePearl(mc, ob, oe);
            landBlock = ob[0];
            landBox = oe[0];
        }

        // 2) Dang nhin thang vao doi thu
        if (cfg.targetPlayer && mc.crosshairTarget instanceof EntityHitResult) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof PlayerEntity && e != mc.player && !e.isSpectator()) lookBox = e.getBoundingBox();
        }

        if (landBlock == null && landBox == null && lookBox == null) return;

        int idx = Math.floorMod(cfg.highlightColor, RGB.length);
        int r = (RGB[idx] >> 16) & 0xFF, g = (RGB[idx] >> 8) & 0xFF, b = RGB[idx] & 0xFF;

        Vec3d cam = ctx.camera().getPos();
        VertexConsumer vc = IMM.getBuffer(RenderLayer.getLines());
        MatrixStack.Entry entry = ms.peek();

        if (landBlock != null) {
            Box bx = new Box(landBlock).expand(0.002);
            box(vc, entry, bx, cam, r, g, b);
            faceCrosses(vc, entry, bx, cam, r, g, b);
        }
        if (landBox != null) box(vc, entry, landBox.expand(0.05), cam, r, g, b);
        if (lookBox != null) box(vc, entry, lookBox.expand(0.05), cam, r, g, b);

        IMM.draw();
    }

    private static boolean holdingPearl(MinecraftClient mc) {
        return mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)
                || mc.player.getOffHandStack().isOf(Items.ENDER_PEARL);
    }

    /** Mo phong quy dao ender pearl (toc do 1.5, trong luc 0.03, can 0.99). */
    private static void simulatePearl(MinecraftClient mc, BlockPos[] outBlock, Box[] outBox) {
        ClientPlayerEntity p = mc.player;
        double yaw = Math.toRadians(p.getYaw());
        double pitch = Math.toRadians(p.getPitch());
        double f = -Math.sin(yaw) * Math.cos(pitch);
        double g = -Math.sin(pitch);
        double h = Math.cos(yaw) * Math.cos(pitch);
        Vec3d vel = new Vec3d(f, g, h).normalize().multiply(1.5);
        Vec3d pv = p.getVelocity();
        vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
        Vec3d pos = new Vec3d(p.getX(), p.getEyeY() - 0.1, p.getZ());

        for (int i = 0; i < 200; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult br = mc.world.raycast(new RaycastContext(
                    pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            boolean hitBlock = br.getType() == HitResult.Type.BLOCK;
            Vec3d end = hitBlock ? br.getPos() : next;

            for (PlayerEntity o : mc.world.getPlayers()) {
                if (o == p || o.isSpectator() || !o.isAlive()) continue;
                Box bb = o.getBoundingBox().expand(0.3);
                if (bb.contains(pos) || bb.raycast(pos, end).isPresent()) {
                    outBox[0] = o.getBoundingBox();
                    return;
                }
            }
            if (hitBlock) {
                outBlock[0] = br.getBlockPos();
                return;
            }
            pos = next;
            vel = vel.multiply(0.99).subtract(0.0, 0.03, 0.0);
            if (pos.y < mc.world.getBottomY()) return;
        }
    }

    // ---------- ve ----------

    private static void box(VertexConsumer vc, MatrixStack.Entry e, Box b, Vec3d cam, int r, int g, int bl) {
        double x1 = b.minX - cam.x, y1 = b.minY - cam.y, z1 = b.minZ - cam.z;
        double x2 = b.maxX - cam.x, y2 = b.maxY - cam.y, z2 = b.maxZ - cam.z;
        // day
        line(vc, e, x1, y1, z1, x2, y1, z1, r, g, bl);
        line(vc, e, x2, y1, z1, x2, y1, z2, r, g, bl);
        line(vc, e, x2, y1, z2, x1, y1, z2, r, g, bl);
        line(vc, e, x1, y1, z2, x1, y1, z1, r, g, bl);
        // dinh
        line(vc, e, x1, y2, z1, x2, y2, z1, r, g, bl);
        line(vc, e, x2, y2, z1, x2, y2, z2, r, g, bl);
        line(vc, e, x2, y2, z2, x1, y2, z2, r, g, bl);
        line(vc, e, x1, y2, z2, x1, y2, z1, r, g, bl);
        // cot
        line(vc, e, x1, y1, z1, x1, y2, z1, r, g, bl);
        line(vc, e, x2, y1, z1, x2, y2, z1, r, g, bl);
        line(vc, e, x2, y1, z2, x2, y2, z2, r, g, bl);
        line(vc, e, x1, y1, z2, x1, y2, z2, r, g, bl);
    }

    /** Duong cheo chu X tren 6 mat de block de thay hon. */
    private static void faceCrosses(VertexConsumer vc, MatrixStack.Entry e, Box b, Vec3d cam, int r, int g, int bl) {
        double x1 = b.minX - cam.x, y1 = b.minY - cam.y, z1 = b.minZ - cam.z;
        double x2 = b.maxX - cam.x, y2 = b.maxY - cam.y, z2 = b.maxZ - cam.z;
        // day / dinh
        line(vc, e, x1, y1, z1, x2, y1, z2, r, g, bl);
        line(vc, e, x2, y1, z1, x1, y1, z2, r, g, bl);
        line(vc, e, x1, y2, z1, x2, y2, z2, r, g, bl);
        line(vc, e, x2, y2, z1, x1, y2, z2, r, g, bl);
        // truoc / sau (z)
        line(vc, e, x1, y1, z1, x2, y2, z1, r, g, bl);
        line(vc, e, x2, y1, z1, x1, y2, z1, r, g, bl);
        line(vc, e, x1, y1, z2, x2, y2, z2, r, g, bl);
        line(vc, e, x2, y1, z2, x1, y2, z2, r, g, bl);
        // trai / phai (x)
        line(vc, e, x1, y1, z1, x1, y2, z2, r, g, bl);
        line(vc, e, x1, y1, z2, x1, y2, z1, r, g, bl);
        line(vc, e, x2, y1, z1, x2, y2, z2, r, g, bl);
        line(vc, e, x2, y1, z2, x2, y2, z1, r, g, bl);
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry e,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             int r, int g, int b) {
        float nx = (float) (x2 - x1), ny = (float) (y2 - y1), nz = (float) (z2 - z1);
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len == 0.0f) return;
        nx /= len; ny /= len; nz /= len;
        Matrix4f m = e.getPositionMatrix();
        vc.vertex(m, (float) x1, (float) y1, (float) z1).color(r, g, b, 255).normal(e, nx, ny, nz);
        vc.vertex(m, (float) x2, (float) y2, (float) z2).color(r, g, b, 255).normal(e, nx, ny, nz);
    }
}
