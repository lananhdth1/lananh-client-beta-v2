package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Locale;

/** Cai dat Block ESP: bat/tat nhom block, mau, them/xoa block bang ID. */
public class BlockEspScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget field;
    private String status = "";
    private int infoY;

    public BlockEspScreen(Screen parent) {
        super(Text.literal("Block ESP"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.INSTANCE;
        int colW = 150, gap = 8, rowH = 22, rows = 7;
        int left = this.width / 2 - colW - gap / 2;
        int right = this.width / 2 + gap / 2;
        int top = Math.max(24, this.height / 2 - (rows * rowH) / 2 - 4);

        addDrawableChild(ConfigScreen.toggle("Block ESP", () -> c.espBlocks, v -> c.espBlocks = v, left, top, colW));
        addDrawableChild(new ConfigScreen.ConfigSlider(right, top, colW, 20, "Range", 16, 128, 16,
                c.espBlkRange, v -> c.espBlkRange = v));

        addDrawableChild(ConfigScreen.toggle("Ores", () -> c.espBlkOres, v -> c.espBlkOres = v, left, top + rowH, colW));
        addDrawableChild(EspScreen.colorButton("Ores", () -> c.espBlkOreColor, v -> c.espBlkOreColor = v, right, top + rowH, colW));

        addDrawableChild(ConfigScreen.toggle("Utility", () -> c.espBlkUtility, v -> c.espBlkUtility = v, left, top + rowH * 2, colW));
        addDrawableChild(EspScreen.colorButton("Utility", () -> c.espBlkUtilityColor, v -> c.espBlkUtilityColor = v, right, top + rowH * 2, colW));

        addDrawableChild(ConfigScreen.toggle("Spawner/Beacon", () -> c.espBlkSpecial, v -> c.espBlkSpecial = v, left, top + rowH * 3, colW));
        addDrawableChild(EspScreen.colorButton("Special", () -> c.espBlkSpecialColor, v -> c.espBlkSpecialColor = v, right, top + rowH * 3, colW));

        addDrawableChild(EspScreen.colorButton("Custom", () -> c.espBlkCustomColor, v -> c.espBlkCustomColor = v, left, top + rowH * 4, colW));
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear Custom"), b -> {
            c.espBlkCustom.clear();
            status = "§eDa xoa het block tu them";
        }).dimensions(right, top + rowH * 4, colW, 20).build());

        // O nhap ID + Add / Remove
        field = new TextFieldWidget(this.textRenderer, left, top + rowH * 5, 180, 20, Text.literal("Block ID"));
        field.setMaxLength(64);
        field.setSuggestion("minecraft:diamond_ore");
        field.setChangedListener(t -> field.setSuggestion(t.isEmpty() ? "minecraft:diamond_ore" : ""));
        addDrawableChild(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> addBlock())
                .dimensions(left + 184, top + rowH * 5, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Del"), b -> removeBlock())
                .dimensions(left + 248, top + rowH * 5, 60, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 - 100, top + rowH * 6 + 4, 200, 20).build());
        infoY = top + rowH * 6 + 30;
    }

    private Identifier parse() {
        String s = field.getText().trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return null;
        if (!s.contains(":")) s = "minecraft:" + s;
        Identifier id = Identifier.tryParse(s);
        if (id == null || !Registries.BLOCK.containsId(id) || Registries.BLOCK.get(id) == Blocks.AIR) {
            status = "§cBlock khong ton tai: " + s;
            return null;
        }
        return id;
    }

    private void addBlock() {
        Identifier id = parse();
        if (id == null) return;
        List<String> l = Config.INSTANCE.espBlkCustom;
        String s = id.toString();
        if (l.contains(s)) { status = "§eDa co san: " + s; return; }
        if (l.size() >= 64) { status = "§cToi da 64 block"; return; }
        l.add(s);
        field.setText("");
        status = "§aDa them: " + s;
    }

    private void removeBlock() {
        Identifier id = parse();
        if (id == null) return;
        String s = id.toString();
        status = Config.INSTANCE.espBlkCustom.remove(s) ? "§aDa xoa: " + s : "§eKhong co trong danh sach: " + s;
        field.setText("");
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Custom: " + Config.INSTANCE.espBlkCustom.size() + " block   (vd: diamond_ore)"),
                this.width / 2, infoY, 0xAAAAAA);
        if (!status.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(status), this.width / 2, infoY + 12, 0xFFFFFF);
        }
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public void removed() {
        Config.save();
    }
}
