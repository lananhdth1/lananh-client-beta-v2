package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Cai dat Auto Mace. */
public class MaceScreen extends Screen {
    private final Screen parent;
    private int hintY;

    public MaceScreen(Screen parent) {
        super(Text.literal("Auto Mace"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.INSTANCE;
        int colW = 150, gap = 8, rowH = 22, rows = 4;
        int left = this.width / 2 - colW - gap / 2;
        int right = this.width / 2 + gap / 2;
        int top = Math.max(24, this.height / 2 - (rows * rowH) / 2 - 4);

        addDrawableChild(ConfigScreen.toggle("Auto Mace", () -> c.autoMace, v -> c.autoMace = v, left, top, colW));
        addDrawableChild(ConfigScreen.toggle("Swap Chestplate", () -> c.maceSwapChest, v -> c.maceSwapChest = v, right, top, colW));

        addDrawableChild(new ConfigScreen.ConfigSlider(left, top + rowH, colW, 20, "Range", 16, 128, 8,
                c.maceRange, v -> c.maceRange = v));
        addDrawableChild(new ConfigScreen.ConfigSlider(right, top + rowH, colW, 20, "Dive Dist", 4, 20, 1,
                c.maceDiveDist, v -> c.maceDiveDist = v));

        addDrawableChild(new ConfigScreen.ConfigSlider(left, top + rowH * 2, colW, 20, "Hover Height", 8, 40, 2,
                c.maceHover, v -> c.maceHover = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 - 100, top + rowH * 3 + 4, 200, 20).build());
        hintY = top + rowH * 3 + 30;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Bat Auto Mace o day, roi bam F5 (goc nhin thu 3) de kich hoat"),
                this.width / 2, hintY, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Can: elytra + chestplate + firework + mace (tren hotbar)"),
                this.width / 2, hintY + 12, 0xAAAAAA);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public void removed() {
        Config.save();
    }
}
