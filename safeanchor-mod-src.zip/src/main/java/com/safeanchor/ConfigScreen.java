package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

public class ConfigScreen extends Screen {
    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Safe Anchor"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.INSTANCE;
        int colW = 150, gap = 8, rowH = 22, rows = 11;
        int left = this.width / 2 - colW - gap / 2;
        int right = this.width / 2 + gap / 2;
        int top = Math.max(24, this.height / 2 - (rows * rowH) / 2 - 4);

        // Hang 0
        addDrawableChild(toggle("Mod", () -> c.enabled, v -> c.enabled = v, left, top, colW));
        addDrawableChild(toggle("Auto Shield", () -> c.autoShield, v -> c.autoShield = v, right, top, colW));
        // Hang 1
        addDrawableChild(toggle("Anchor Macro", () -> c.macro, v -> c.macro = v, left, top + rowH, colW));
        addDrawableChild(toggle("Smart Detect", () -> c.smart, v -> c.smart = v, right, top + rowH, colW));
        // Hang 2
        addDrawableChild(toggle("Crystal Macro", () -> c.crystal, v -> c.crystal = v, left, top + rowH * 2, colW));
        addDrawableChild(toggle("Require Pearl", () -> c.requirePearl, v -> c.requirePearl = v, right, top + rowH * 2, colW));
        // Highlight
        addDrawableChild(toggle("Highlight", () -> c.highlight, v -> c.highlight = v, left, top + rowH * 3, colW));
        addDrawableChild(toggle("Pearl Landing", () -> c.pearlLanding, v -> c.pearlLanding = v, right, top + rowH * 3, colW));
        addDrawableChild(toggle("Target Player", () -> c.targetPlayer, v -> c.targetPlayer = v, left, top + rowH * 4, colW));
        addDrawableChild(colorButton(right, top + rowH * 4, colW));
        // Sliders
        addDrawableChild(new ConfigSlider(left, top + rowH * 5, colW, 20, "Anchor Delay", 0, 20, 1,
                c.delay, v -> c.delay = (int) Math.round(v)));
        addDrawableChild(new ConfigSlider(right, top + rowH * 5, colW, 20, "Crystal Delay", 0, 20, 1,
                c.crystalDelay, v -> c.crystalDelay = (int) Math.round(v)));
        // Hang 4
        addDrawableChild(new ConfigSlider(left, top + rowH * 6, colW, 20, "Min Damage", 0, 20, 0.5,
                c.minDamage, v -> c.minDamage = v));
        addDrawableChild(new ConfigSlider(right, top + rowH * 6, colW, 20, "Stop at HP", 0, 20, 0.5,
                c.minSelfHealth, v -> c.minSelfHealth = v));
        // Hang 5
        addDrawableChild(new ConfigSlider(left, top + rowH * 7, colW, 20, "Max Self Dmg", 0, 20, 0.5,
                c.maxSelfDamage, v -> c.maxSelfDamage = v));
        addDrawableChild(new ConfigSlider(right, top + rowH * 7, colW, 20, "Adjacent Range", 0, 6, 0.5,
                c.adjacentRange, v -> c.adjacentRange = v));
        // ESP + Block ESP
        addDrawableChild(ButtonWidget.builder(Text.literal("ESP Settings..."),
                        b -> { if (this.client != null) this.client.setScreen(new EspScreen(this)); })
                .dimensions(left, top + rowH * 8, colW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Block ESP..."),
                        b -> { if (this.client != null) this.client.setScreen(new BlockEspScreen(this)); })
                .dimensions(right, top + rowH * 8, colW, 20).build());
        // Auto Mace
        addDrawableChild(toggle("Auto Mace", () -> c.autoMace, v -> c.autoMace = v, left, top + rowH * 9, colW));
        addDrawableChild(ButtonWidget.builder(Text.literal("Mace Settings..."),
                        b -> { if (this.client != null) this.client.setScreen(new MaceScreen(this)); })
                .dimensions(right, top + rowH * 9, colW, 20).build());
        // Done
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 - 100, top + rowH * 10 + 4, 200, 20).build());
    }


    static ButtonWidget toggle(String label, BooleanSupplier get, Consumer<Boolean> set, int x, int y, int w) {
        return ButtonWidget.builder(toggleText(label, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(toggleText(label, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
    }

    private static ButtonWidget colorButton(int x, int y, int w) {
        return ButtonWidget.builder(colorText(), b -> {
            Config.INSTANCE.highlightColor = (Config.INSTANCE.highlightColor + 1) % Highlight.NAMES.length;
            b.setMessage(colorText());
        }).dimensions(x, y, w, 20).build();
    }

    private static Text colorText() {
        int i = Math.floorMod(Config.INSTANCE.highlightColor, Highlight.NAMES.length);
        int rgb = Highlight.RGB[i];
        return Text.literal("Color: ").append(Text.literal(Highlight.NAMES[i]).styled(st -> st.withColor(rgb)));
    }

    private static Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public void removed() {
        Config.save();
    }

    /** Thanh keo gia tri tu min..max theo buoc step. */
    static class ConfigSlider extends SliderWidget {
        private final String label;
        private final double min, max, step;
        private final DoubleConsumer setter;

        ConfigSlider(int x, int y, int w, int h, String label, double min, double max, double step,
                     double current, DoubleConsumer setter) {
            super(x, y, w, h, Text.empty(), Math.max(0.0, Math.min(1.0, (current - min) / (max - min))));
            this.label = label;
            this.min = min;
            this.max = max;
            this.step = step;
            this.setter = setter;
            updateMessage();
        }

        private double actual() {
            double v = min + this.value * (max - min);
            return Math.round(v / step) * step;
        }

        @Override
        protected void updateMessage() {
            double a = actual();
            String s = step >= 1.0 ? String.valueOf((int) Math.round(a)) : String.format(Locale.ROOT, "%.1f", a);
            setMessage(Text.literal(label + ": " + s));
        }

        @Override
        protected void applyValue() {
            setter.accept(actual());
        }
    }
}
