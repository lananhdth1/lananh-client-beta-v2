package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP kieu Meteor: ve vien (Outline) / to mau (Fill) quanh Players, Mobs, Storage
 * xuyen tuong. Co Tracers (duong ke tu tam man hinh toi entity).
 */
public class Esp {
    public static final String[] MODES = {"Outline", "Fill", "Both"};
    public static final String[] COLOR_NAMES = {
            "Light Pink", "Hot Pink", "Red", "Orange", "Yellow", "Lime", "Cyan", "Blue", "Purple", "White"};
    public static final int[] COLORS = {
            0xFFB6C1, 0xFF69B4, 0xFF3B3B, 0xFFA500, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5588FF, 0xAA66FF, 0xFFFFFF};

    record Target(Box box, int rgb, boolean tracer) {}

    public static int indexOf(int rgb) {
        for (int i = 0; i < COLORS.length; i++) if (COLORS[i] == rgb) return i;
        return -1;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config cfg = Config.INSTANCE;
        if (!cfg.enabled || mc.player == null || mc.world == null) return;
        boolean entOn = cfg.esp && (cfg.espPlayers || cfg.espMobs || cfg.espStorage);
        if (!entOn && !cfg.espBlocks) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        float delta = mc.getRenderTickCounter().getTickDelta(false);
        double range = Math.max(8.0, cfg.espRange);
        double range2 = range * range;
        List<Target> targets = new ArrayList<>();

        // ---- Players / Mobs ----
        if (entOn && (cfg.espPlayers || cfg.espMobs)) {
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || e.isRemoved() || e.isSpectator()) continue;
                int rgb;
                if (e instanceof PlayerEntity) {
                    if (!cfg.espPlayers) continue;
                    rgb = cfg.espPlayerColor;
                } else if (e instanceof MobEntity) {
                    if (!cfg.espMobs) continue;
                    rgb = cfg.espMobColor;
                } else {
                    continue;
                }
                if (mc.player.squaredDistanceTo(e) > range2) continue;
                Vec3d shift = e.getLerpedPos(delta).subtract(e.getPos());
                targets.add(new Target(e.getBoundingBox().offset(shift), rgb, true));
            }
        }

        // ---- Storage (chest, trapped chest, barrel, ender chest, shulker) ----
        if (entOn && cfg.espStorage) {
            int cr = Math.min(mc.options.getClampedViewDistance(), (int) Math.ceil(range / 16.0) + 1);
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            for (int dx = -cr; dx <= cr; dx++) {
                for (int dz = -cr; dz <= cr; dz++) {
                    WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                    if (chunk == null) continue;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        int rgb;
                        if (be instanceof EnderChestBlockEntity) rgb = cfg.espEnderColor;
                        else if (be instanceof ShulkerBoxBlockEntity) rgb = cfg.espShulkerColor;
                        else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) rgb = cfg.espChestColor;
                        else continue;
                        BlockPos p = be.getPos();
                        if (mc.player.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) > range2) continue;
                        VoxelShape shape = be.getCachedState().getOutlineShape(mc.world, p);
                        Box box = shape.isEmpty() ? new Box(p) : shape.getBoundingBox().offset(p);
                        targets.add(new Target(box, rgb, false));
                    }
                }
            }
        }

        // ---- Block ESP (quet chunk, xem BlockEsp) ----
        if (cfg.espBlocks) BlockEsp.collect(targets, mc);

        if (targets.isEmpty()) return;

        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        MatrixStack.Entry entry = ms.peek();
        Matrix4f m = entry.getPositionMatrix();
        int mode = Math.floorMod(cfg.espMode, MODES.length);
        int alpha = Math.max(0, Math.min(255, cfg.espAlpha));

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();   // nhin xuyen tuong
        RenderSystem.disableCull();

        // 1) To mau
        if (mode == 1 || mode == 2) {
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Target t : targets) fill(bb, m, t.box(), cam, t.rgb(), alpha);
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }

        // 2) Vien + tracers
        boolean wantOutline = mode == 0 || mode == 2;
        boolean wantTracers = cfg.espTracers;
        int lineCount = 0;
        if (wantOutline) lineCount = targets.size();
        else if (wantTracers) for (Target t : targets) if (t.tracer()) lineCount++;

        if (lineCount > 0) {
            RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
            RenderSystem.lineWidth((float) Math.max(1.0, Math.min(6.0, cfg.espThickness)));
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
            Vec3d start = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.5);
            for (Target t : targets) {
                int r = (t.rgb() >> 16) & 0xFF, g = (t.rgb() >> 8) & 0xFF, b = t.rgb() & 0xFF;
                if (wantOutline) outline(bb, entry, t.box(), cam, r, g, b);
                if (wantTracers && t.tracer()) {
                    Vec3d c = t.box().getCenter().subtract(cam);
                    line(bb, entry, (float) start.x, (float) start.y, (float) start.z,
                            (float) c.x, (float) c.y, (float) c.z, r, g, b, 220);
                }
            }
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // ---------- ve ----------

    private static void fill(VertexConsumer vc, Matrix4f m, Box bx, Vec3d cam, int rgb, int a) {
        float x1 = (float) (bx.minX - cam.x), y1 = (float) (bx.minY - cam.y), z1 = (float) (bx.minZ - cam.z);
        float x2 = (float) (bx.maxX - cam.x), y2 = (float) (bx.maxY - cam.y), z2 = (float) (bx.maxZ - cam.z);
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        quad(vc, m, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, r, g, b, a); // day
        quad(vc, m, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, r, g, b, a); // dinh
        quad(vc, m, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, r, g, b, a); // z1
        quad(vc, m, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, r, g, b, a); // z2
        quad(vc, m, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, r, g, b, a); // x1
        quad(vc, m, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, r, g, b, a); // x2
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             int r, int g, int b, int a) {
        vc.vertex(m, ax, ay, az).color(r, g, b, a);
        vc.vertex(m, bx, by, bz).color(r, g, b, a);
        vc.vertex(m, cx, cy, cz).color(r, g, b, a);
        vc.vertex(m, dx, dy, dz).color(r, g, b, a);
    }

    private static void outline(VertexConsumer vc, MatrixStack.Entry e, Box bx, Vec3d cam, int r, int g, int b) {
        float x1 = (float) (bx.minX - cam.x), y1 = (float) (bx.minY - cam.y), z1 = (float) (bx.minZ - cam.z);
        float x2 = (float) (bx.maxX - cam.x), y2 = (float) (bx.maxY - cam.y), z2 = (float) (bx.maxZ - cam.z);
        // day
        line(vc, e, x1, y1, z1, x2, y1, z1, r, g, b, 255);
        line(vc, e, x2, y1, z1, x2, y1, z2, r, g, b, 255);
        line(vc, e, x2, y1, z2, x1, y1, z2, r, g, b, 255);
        line(vc, e, x1, y1, z2, x1, y1, z1, r, g, b, 255);
        // dinh
        line(vc, e, x1, y2, z1, x2, y2, z1, r, g, b, 255);
        line(vc, e, x2, y2, z1, x2, y2, z2, r, g, b, 255);
        line(vc, e, x2, y2, z2, x1, y2, z2, r, g, b, 255);
        line(vc, e, x1, y2, z2, x1, y2, z1, r, g, b, 255);
        // cot
        line(vc, e, x1, y1, z1, x1, y2, z1, r, g, b, 255);
        line(vc, e, x2, y1, z1, x2, y2, z1, r, g, b, 255);
        line(vc, e, x2, y1, z2, x2, y2, z2, r, g, b, 255);
        line(vc, e, x1, y1, z2, x1, y2, z2, r, g, b, 255);
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry e,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             int r, int g, int b, int a) {
        float nx = x2 - x1, ny = y2 - y1, nz = z2 - z1;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len == 0.0f) return;
        nx /= len; ny /= len; nz /= len;
        Matrix4f m = e.getPositionMatrix();
        vc.vertex(m, x1, y1, z1).color(r, g, b, a).normal(e, nx, ny, nz);
        vc.vertex(m, x2, y2, z2).color(r, g, b, a).normal(e, nx, ny, nz);
    }
}
