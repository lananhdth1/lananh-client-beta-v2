package com.safeanchor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.function.Predicate;

public class SafeAnchorClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static KeyBinding menuKey;

    // macro (giu chuot phai)
    private static BlockPos anchorPos;
    private static Direction anchorFace;
    private static int phase = 0;     // 0 = nap glowstone, 1 = block chan, 2 = no
    private static int cooldown = 0;

    // auto shield (ngay khi dat anchor)
    private static BlockPos pendingAnchor;
    private static int pendingTicks = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.safeanchor.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.safeanchor"));

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.safeanchor.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.safeanchor"));

        // Bat khoanh khac ban dat anchor
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient && Config.INSTANCE.enabled && Config.INSTANCE.autoShield
                    && player.getStackInHand(hand).isOf(Items.RESPAWN_ANCHOR)) {
                BlockPos clicked = hit.getBlockPos();
                if (!world.getBlockState(clicked).isOf(Blocks.RESPAWN_ANCHOR)) {
                    BlockPos placed = world.getBlockState(clicked).isReplaceable()
                            ? clicked : clicked.offset(hit.getSide());
                    pendingAnchor = placed.toImmutable();
                    pendingTicks = 0;
                }
            }
            return ActionResult.PASS;
        });

        // Danh doi thu => kich hoat crystal macro (neu da nem pearl)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient) CrystalMacro.onAttack(player, entity);
            return ActionResult.PASS;
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(Highlight::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Esp::render);

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private static String onOff(boolean b) { return b ? "§aON" : "§cOFF"; }

    private static void toggle(MinecraftClient mc) {
        Config.INSTANCE.enabled = !Config.INSTANCE.enabled;
        Config.save();
        reset();
        pendingAnchor = null;
        CrystalMacro.stop();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("Safe Anchor: " + onOff(Config.INSTANCE.enabled)), true);
        }
    }

    private static void reset() {
        anchorPos = null;
        anchorFace = null;
        phase = 0;
        cooldown = 0;
    }

    private void tick(MinecraftClient mc) {
        while (toggleKey.wasPressed()) toggle(mc);
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) mc.setScreen(new ConfigScreen(null));
        }

        BlockEsp.tick(mc);
        AutoMace.tick(mc);

        if (!Config.INSTANCE.enabled || mc.player == null || mc.world == null || mc.interactionManager == null) {
            reset();
            pendingAnchor = null;
            return;
        }

        CrystalMacro.tick(mc);

        // ---- AUTO SHIELD: ngay khi anchor xuat hien thi dat block chan ----
        if (pendingAnchor != null) {
            if (mc.world.getBlockState(pendingAnchor).isOf(Blocks.RESPAWN_ANCHOR)) {
                shield(mc, pendingAnchor);
                pendingAnchor = null;
            } else if (++pendingTicks > 10) {
                pendingAnchor = null;
            }
        }

        // ---- MACRO: giu chuot phai vao anchor ----
        if (!Config.INSTANCE.macro || mc.currentScreen != null || !mc.options.useKey.isPressed()) {
            reset();
            return;
        }

        if (anchorPos == null) {
            if (mc.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK
                    && mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
                anchorPos = hit.getBlockPos();
                anchorFace = hit.getSide();
                phase = 0;
                cooldown = 0;
            } else {
                return;
            }
        }

        BlockState state = mc.world.getBlockState(anchorPos);
        if (!state.isOf(Blocks.RESPAWN_ANCHOR)) { anchorPos = null; return; }

        if (cooldown > 0) { cooldown--; return; }

        var inv = mc.player.getInventory();
        int prevSlot = inv.selectedSlot;
        BlockHitResult anchorHit = new BlockHitResult(Vec3d.ofCenter(anchorPos), anchorFace, anchorPos, false);

        // Buoc 0: nap glowstone
        if (phase == 0) {
            if (state.get(RespawnAnchorBlock.CHARGES) > 0) {
                phase = 1;
            } else {
                int slot = findSlot(mc, s -> s.isOf(Items.GLOWSTONE));
                if (slot == -1) { msg(mc, "§cKhong co glowstone!"); return; }
                use(mc, slot, anchorHit, prevSlot);
                phase = 1;
                cooldown = Config.INSTANCE.delay;
                return;
            }
        }

        // Buoc 1: block chan (bo qua neu da co / doi thu cung duoc che)
        if (phase == 1) {
            phase = 2;
            if (shield(mc, anchorPos)) {
                cooldown = Config.INSTANCE.delay;
                return;
            }
        }

        // Buoc 2: no anchor
        if (phase == 2) {
            int slot = !inv.getStack(prevSlot).isOf(Items.GLOWSTONE)
                    ? prevSlot : findSlot(mc, s -> !s.isOf(Items.GLOWSTONE));
            if (slot == -1) slot = prevSlot;
            use(mc, slot, anchorHit, prevSlot);
            phase = 0;
            cooldown = Config.INSTANCE.delay;
        }
    }

    // ================== SHIELD ==================

    /** Dat block chan giua ban va anchor. Tra ve true neu da dat. Khong doi goc nhin. */
    private static boolean shield(MinecraftClient mc, BlockPos anchor) {
        BlockPos target = shieldTarget(mc, anchor);
        if (target == null) return false; // da co block chan san

        if (Config.INSTANCE.smart && opponentAlsoCovered(mc, anchor, target)) return false;

        BlockHitResult hit = supportHit(mc, target, anchor);
        if (hit == null) { msg(mc, "§eKhong co cho tua de dat block chan"); return false; }

        int slot = pickShieldSlot(mc);
        if (slot == -1) { msg(mc, "§cKhong co obsidian / glowstone de chan!"); return false; }

        use(mc, slot, hit, mc.player.getInventory().selectedSlot);
        return true;
    }

    /** O block nam tren duong thang tu tam anchor toi mat ban (ngay canh anchor). */
    private static BlockPos shieldTarget(MinecraftClient mc, BlockPos anchor) {
        Vec3d from = Vec3d.ofCenter(anchor);
        Vec3d to = mc.player.getEyePos();
        Vec3d dir = to.subtract(from);
        double len = dir.length();
        if (len < 0.5) return null;
        for (double t = 0.3; t <= len; t += 0.1) {
            BlockPos p = BlockPos.ofFloored(from.add(dir.multiply(t / len)));
            if (!p.equals(anchor)) {
                return mc.world.getBlockState(p).isReplaceable() ? p : null;
            }
        }
        return null;
    }

    /**
     * Doi thu dung ke ban, hoac block chan nay cung che luon cho doi thu
     * (doi thu nam "sau" block) => khong dat de doi thu khong duoc loi.
     */
    private static boolean opponentAlsoCovered(MinecraftClient mc, BlockPos anchor, BlockPos target) {
        Vec3d from = Vec3d.ofCenter(anchor);
        Box shieldBox = new Box(target);
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == mc.player || other.isSpectator() || !other.isAlive()) continue;
            if (other.getPos().distanceTo(from) > 7.0) continue;            // ngoai pham vi no
            if (other.distanceTo(mc.player) <= Config.INSTANCE.adjacentRange) return true; // dung ke
            Vec3d body = other.getBoundingBox().getCenter();
            if (shieldBox.raycast(from, body).isPresent()) return true;       // cung nam sau block
        }
        return false;
    }

    static BlockHitResult supportHit(MinecraftClient mc, BlockPos target, BlockPos anchor) {
        for (Direction d : Direction.values()) {
            BlockPos support = target.offset(d);
            if (support.equals(anchor)) continue;
            if (!mc.world.getBlockState(support).isSolidBlock(mc.world, support)) continue;
            Direction face = d.getOpposite();
            Vec3d pos = Vec3d.ofCenter(support).add(Vec3d.of(face.getVector()).multiply(0.5));
            return new BlockHitResult(pos, face, support, false);
        }
        return null;
    }

    /** Uu tien obsidian, roi den glowstone, roi block khac. */
    private static int pickShieldSlot(MinecraftClient mc) {
        int s = findSlot(mc, i -> i.isOf(Items.OBSIDIAN));
        if (s == -1) s = findSlot(mc, i -> i.isOf(Items.CRYING_OBSIDIAN));
        if (s == -1) s = findSlot(mc, i -> i.isOf(Items.GLOWSTONE));
        if (s == -1) s = findSlot(mc, i -> i.getItem() instanceof BlockItem && !i.isOf(Items.RESPAWN_ANCHOR));
        return s;
    }

    // ================== UTIL ==================

    static void use(MinecraftClient mc, int slot, BlockHitResult hit, int prevSlot) {
        var inv = mc.player.getInventory();
        inv.selectedSlot = slot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        inv.selectedSlot = prevSlot;
    }

    static int findSlot(MinecraftClient mc, Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && p.test(s)) return i;
        }
        return -1;
    }

    static void msg(MinecraftClient mc, String text) {
        mc.player.sendMessage(Text.literal(text), true);
    }
}
