package com.safeanchor;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Nem pearl -> danh doi thu 1 cai -> tu dat obsidian + crystal va no.
 * Dung khi: doi thu chet, mau ban qua thap, hoac sat thuong len doi thu qua thap.
 */
public class CrystalMacro {
    private static final double REACH = 4.5;

    private static int armedTicks = 0;
    private static PlayerEntity target = null;
    private static int activeTicks = 0;
    private static int lowTicks = 0;
    private static int cooldown = 0;

    public static void stop() {
        target = null;
        activeTicks = 0;
        lowTicks = 0;
        cooldown = 0;
    }

    /** Duoc goi khi ban danh 1 entity. */
    public static void onAttack(PlayerEntity player, Entity entity) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.INSTANCE.enabled || !Config.INSTANCE.crystal) return;
        if (mc.player == null || player != mc.player) return;
        if (target != null) return;
        if (!(entity instanceof PlayerEntity)) return;
        PlayerEntity victim = (PlayerEntity) entity;
        if (victim == mc.player || victim.isSpectator()) return;
        if (Config.INSTANCE.requirePearl && armedTicks <= 0) return;

        target = victim;
        activeTicks = 0;
        lowTicks = 0;
        cooldown = 0;
        SafeAnchorClient.msg(mc, "§aCrystal macro: ON -> " + victim.getName().getString());
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            stop();
            armedTicks = 0;
            return;
        }
        if (!Config.INSTANCE.crystal) { stop(); return; }

        // Nhan biet da nem pearl: co pearl cua minh dang bay => "armed" 15 giay
        if (armedTicks > 0) armedTicks--;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EnderPearlEntity && ((EnderPearlEntity) e).getOwner() == mc.player) {
                armedTicks = 300;
                break;
            }
        }

        if (target == null) return;

        if (!target.isAlive() || target.isRemoved() || target.getHealth() <= 0) {
            SafeAnchorClient.msg(mc, "§aDoi thu da chet / bien mat - dung");
            stop();
            return;
        }
        if (mc.player.distanceTo(target) > 12) { SafeAnchorClient.msg(mc, "§eDoi thu qua xa - dung"); stop(); return; }

        float myHp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (myHp <= Config.INSTANCE.minSelfHealth) { SafeAnchorClient.msg(mc, "§cMau thap - dung crystal"); stop(); return; }
        if (++activeTicks > 600) { stop(); return; }
        if (cooldown > 0) { cooldown--; return; }

        Vec3d eye = mc.player.getEyePos();

        // 1) Danh crystal dang co san (tot nhat)
        EndCrystalEntity bestCrystal = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        Box area = target.getBoundingBox().expand(8.0);
        for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, area, e -> true)) {
            if (eye.distanceTo(c.getBoundingBox().getCenter()) > REACH) continue;
            double sc = evaluate(mc, c.getPos(), myHp);
            if (sc > bestScore) { bestScore = sc; bestCrystal = c; }
        }
        if (bestCrystal != null) {
            mc.interactionManager.attackEntity(mc.player, bestCrystal);
            mc.player.swingHand(Hand.MAIN_HAND);
            cooldown = Config.INSTANCE.crystalDelay;
            lowTicks = 0;
            return;
        }

        BlockPos tp = target.getBlockPos();

        // 2) Dat crystal len obsidian/bedrock da co
        BlockPos bestBase = null;
        bestScore = Double.NEGATIVE_INFINITY;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = -2; dy <= 1; dy++) {
                    BlockPos base = tp.add(dx, dy, dz);
                    BlockState bs = mc.world.getBlockState(base);
                    if (!bs.isOf(Blocks.OBSIDIAN) && !bs.isOf(Blocks.BEDROCK)) continue;
                    BlockPos up = base.up();
                    if (!mc.world.getBlockState(up).isAir() || !mc.world.getBlockState(up.up()).isAir()) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(base)) > REACH) continue;
                    if (!mc.world.getOtherEntities(null, crystalBox(up)).isEmpty()) continue;
                    double sc = evaluate(mc, crystalCenter(base), myHp);
                    if (sc > bestScore) { bestScore = sc; bestBase = base; }
                }
            }
        }
        if (bestBase != null) {
            int slot = SafeAnchorClient.findSlot(mc, s -> s.isOf(Items.END_CRYSTAL));
            if (slot == -1) { SafeAnchorClient.msg(mc, "§cHet end crystal!"); stop(); return; }
            BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(bestBase).add(0, 0.5, 0), Direction.UP, bestBase, false);
            SafeAnchorClient.use(mc, slot, hit, mc.player.getInventory().selectedSlot);
            cooldown = Config.INSTANCE.crystalDelay;
            lowTicks = 0;
            return;
        }

        // 3) Chua co obsidian phu hop -> dat 1 obsidian gan doi thu
        BlockPos bestPos = null;
        BlockHitResult bestHit = null;
        bestScore = Double.NEGATIVE_INFINITY;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos p = tp.add(dx, dy, dz);
                    if (!mc.world.getBlockState(p).isReplaceable()) continue;
                    if (!mc.world.getBlockState(p.up()).isAir() || !mc.world.getBlockState(p.up(2)).isAir()) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(p)) > REACH) continue;
                    if (!mc.world.getOtherEntities(null, new Box(p)).isEmpty()) continue;
                    if (!mc.world.getOtherEntities(null, crystalBox(p.up())).isEmpty()) continue;
                    double sc = evaluate(mc, crystalCenter(p), myHp);
                    if (sc <= bestScore) continue;
                    BlockHitResult h = SafeAnchorClient.supportHit(mc, p, null);
                    if (h == null) continue;
                    bestScore = sc; bestPos = p; bestHit = h;
                }
            }
        }
        if (bestPos != null) {
            int slot = SafeAnchorClient.findSlot(mc, s -> s.isOf(Items.OBSIDIAN));
            if (slot == -1) { SafeAnchorClient.msg(mc, "§cHet obsidian!"); stop(); return; }
            SafeAnchorClient.use(mc, slot, bestHit, mc.player.getInventory().selectedSlot);
            cooldown = Config.INSTANCE.crystalDelay;
            lowTicks = 0;
            return;
        }

        // Khong con cach nao gay du sat thuong -> cho 2 giay roi dung
        if (++lowTicks > 40) {
            SafeAnchorClient.msg(mc, "§eSat thuong qua thap - dung crystal");
            stop();
        }
    }

    // ---------- helpers ----------

    private static Box crystalBox(BlockPos up) {
        return new Box(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1);
    }

    private static Vec3d crystalCenter(BlockPos base) {
        return new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
    }

    /** Diem so = sat thuong len doi thu - sat thuong len ban; -vo cung neu khong dat dieu kien. */
    private static double evaluate(MinecraftClient mc, Vec3d center, float myHp) {
        double td = damage(mc, center, target);
        if (td < Config.INSTANCE.minDamage) return Double.NEGATIVE_INFINITY;
        double sd = damage(mc, center, mc.player);
        if (sd > Config.INSTANCE.maxSelfDamage || sd >= myHp - 1.0) return Double.NEGATIVE_INFINITY;
        return td - sd;
    }

    /** Uoc luong sat thuong vu no crystal (power 6) len mot entity. */
    private static double damage(MinecraftClient mc, Vec3d center, LivingEntity e) {
        double d = Math.sqrt(e.squaredDistanceTo(center)) / 12.0;
        if (d > 1.0) return 0.0;
        double impact = (1.0 - d) * exposure(mc, center, e);
        double dmg = (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;

        switch (mc.world.getDifficulty()) {
            case PEACEFUL: return 0.0;
            case EASY: dmg = Math.min(dmg / 2.0 + 1.0, dmg); break;
            case HARD: dmg = dmg * 1.5; break;
            default: break;
        }
        double armor = e.getArmor();
        dmg = dmg * (1.0 - Math.min(20.0, Math.max(armor / 5.0, armor - dmg / 2.0)) / 25.0);
        return dmg;
    }

    /** Ti le co the nhin thay tu tam no toi entity (0..1), lay mau 9 diem. */
    private static double exposure(MinecraftClient mc, Vec3d center, LivingEntity e) {
        Box b = e.getBoundingBox();
        double[] xs = {b.minX, b.maxX};
        double[] ys = {b.minY, b.maxY};
        double[] zs = {b.minZ, b.maxZ};
        int visible = 0, total = 0;
        for (double x : xs) for (double y : ys) for (double z : zs) {
            total++;
            if (canSee(mc, center, new Vec3d(x, y, z), e)) visible++;
        }
        total++;
        if (canSee(mc, center, b.getCenter(), e)) visible++;
        return (double) visible / (double) total;
    }

    private static boolean canSee(MinecraftClient mc, Vec3d from, Vec3d to, Entity e) {
        BlockHitResult r = mc.world.raycast(new RaycastContext(
                from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
        return r.getType() == HitResult.Type.MISS;
    }
}
