package com.safeanchor;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;

public class Config {
    /** Bat/tat toan bo mod */
    public boolean enabled = true;
    /** Tu dat block chan ngay khi ban dat anchor */
    public boolean autoShield = true;
    /** Giu chuot phai vao anchor de tu nap + no */
    public boolean macro = true;
    /** Thong minh: khong dat block neu doi thu cung duoc che / dung ke ban */
    public boolean smart = true;
    /** Doi thu dung trong khoang nay (block) tinh la "dung ke" */
    public double adjacentRange = 2.5;
    /** Highlight: lam sang block pearl se roi xuong / doi thu dang nhin vao */
    public boolean highlight = true;
    public boolean pearlLanding = true;
    public boolean targetPlayer = true;
    /** 0 Lime, 1 Magenta, 2 Cyan, 3 Yellow, 4 Red, 5 White */
    public int highlightColor = 0;
    /** Crystal macro: nem pearl + danh doi thu 1 cai => tu dat obsidian + crystal va no */
    public boolean crystal = true;
    /** Bat buoc phai nem pearl truoc khi danh thi crystal macro moi chay */
    public boolean requirePearl = true;
    /** Dung khi sat thuong len doi thu thap hon muc nay (HP) */
    public double minDamage = 3.0;
    /** Dung khi mau cua ban (HP) <= muc nay */
    public double minSelfHealth = 8.0;
    /** Moi crystal gay toi da bao nhieu sat thuong len ban (HP) */
    public double maxSelfDamage = 6.0;
    /** Tick giua cac hanh dong crystal (0 = nhanh nhat) */
    public int crystalDelay = 1;
    /** So tick giua cac buoc cua macro (20 tick = 1 giay). 0 = nhanh nhat. */
    public int delay = 1;

    /** ===== ESP: ve vien / to mau xuyen tuong quanh entity + storage ===== */
    public boolean esp = true;
    public boolean espPlayers = true;
    public boolean espMobs = false;
    public boolean espStorage = true;
    public boolean espTracers = false;
    /** 0 Outline, 1 Fill, 2 Both */
    public int espMode = 2;
    /** Do day vien (1..6) */
    public double espThickness = 2.0;
    /** Do dac cua phan to mau (0..255) */
    public int espAlpha = 80;
    /** Khoang cach toi da (block) */
    public double espRange = 128.0;
    public int espPlayerColor = 0xFFB6C1;
    public int espMobColor = 0xFFA500;
    public int espChestColor = 0xFF69B4;
    public int espEnderColor = 0xAA66FF;
    public int espShulkerColor = 0x55FFFF;

    /** ===== Block ESP: to sang block bat ky xuyen tuong (quet chunk quanh ban) ===== */
    public boolean espBlocks = false;
    public boolean espBlkOres = true;      // diamond, ancient debris, emerald
    public boolean espBlkUtility = true;   // lo, hopper, dispenser, dropper
    public boolean espBlkSpecial = true;   // beacon, spawner
    public int espBlkOreColor = 0x00BFFF;
    public int espBlkUtilityColor = 0xFFFF55;
    public int espBlkSpecialColor = 0xFF3B3B;
    public int espBlkCustomColor = 0xFF69B4;
    public double espBlkRange = 48.0;
    /** Block them tay, vd "minecraft:diamond_ore" */
    public List<String> espBlkCustom = new ArrayList<>();

    /** ===== Auto Mace: bat trong menu, roi bam F5 (goc nhin thu 3) de kich hoat ===== */
    public boolean autoMace = false;
    /** Tim doi thu trong ban kinh nay (block) */
    public double maceRange = 64.0;
    /** Khoang cach ngang toi doi thu de bat dau lao xuong */
    public double maceDiveDist = 10.0;
    /** Bay cao hon doi thu bao nhieu block truoc khi lao */
    public double maceHover = 20.0;
    /** Lao xuong thi doi elytra -> chestplate de dung luot + lay fall distance */
    public boolean maceSwapChest = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("safeanchor.json");
    public static Config INSTANCE = new Config();

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) INSTANCE = c;
                if (INSTANCE.espBlkCustom == null) INSTANCE.espBlkCustom = new ArrayList<>();
            }
        } catch (Exception ignored) {}
        save();
    }

    public static void save() {
        try { Files.writeString(FILE, GSON.toJson(INSTANCE)); } catch (Exception ignored) {}
    }
}
