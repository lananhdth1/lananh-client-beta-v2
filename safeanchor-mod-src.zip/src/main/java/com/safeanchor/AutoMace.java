package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

/**
 * Auto Mace. Bat trong menu, roi bam F5 (goc nhin thu 3) de kich hoat:
 *  1) Tim doi thu gan nhat trong ban kinh.
 *  2) Mac elytra, nhay + luot, dung firework bay len cao hon doi thu.
 *  3) Khi con cach doi thu <= Dive Distance (theo chieu ngang): doi elytra -> chestplate
 *     (ngung luot de co fall distance), cam mace, lao xuong.
 *  4) Du tam danh thi tu dap. Doi thu chet -> tim muc tieu khac. Ve goc nhin 1 -> tat.
 */
public class AutoMace {
    private static final Item[] CHESTPLATES = {
            Items.NETHERITE_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.IRON_CHESTPLATE,
            Items.CHAINMAIL_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.LEATHER_CHESTPLATE};

    private static boolean active = false;
    private static boolean strike = false;
    private static PlayerEntity target = null;
    private static int tick = 0, rocketCd = 0, swapCd = 0, warnCd = 0;
    private static boolean jmp = false, fwd = false;

    public static void tick(MinecraftClient mc) {
        Config cfg = Config.INSTANCE;
        boolean on = cfg.enabled && cfg.autoMace && mc.player != null && mc.world != null
                && mc.interactionManager != null && mc.currentScreen == null
                && !mc.options.getPerspective().isFirstPerson();
        if (!on) {
            if (active) stop(mc);
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (!active) {
            active = true;
            strike = false;
            target = null;
            tick = 0; rocketCd = 0; swapCd = 0; warnCd = 0;
            SafeAnchorClient.msg(mc, "§aAuto Mace: ON");
        }
        tick++;
        if (rocketCd > 0) rocketCd--;
        if (swapCd > 0) swapCd--;
        if (warnCd > 0) warnCd--;

        float hp = p.getHealth() + p.getAbsorptionAmount();
        if (hp <= cfg.minSelfHealth) {
            releaseKeys(mc);
            strike = false;
            warn(mc, "§cMau thap - Auto Mace tam dung");
            return;
        }

        if (target == null || !valid(p, target, cfg.maceRange) || (!strike && tick % 20 == 0)) {
            target = findTarget(mc, cfg.maceRange);
        }
        if (target == null) {
            releaseKeys(mc);
            strike = false;
            return;
        }

        Vec3d me = p.getPos();
        Box tb = target.getBoundingBox();
        Vec3d tc = tb.getCenter();
        double dx = tc.x - me.x, dz = tc.z - me.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        double reach = distToBox(p.getEyePos(), tb);
        boolean ground = p.isOnGround();
        boolean glide = gliding(p);
        boolean above = me.y > target.getY() + 3.0;

        // Du dieu kien lao xuong?
        if (!strike && glide && horiz <= cfg.maceDiveDist && above) {
            if (SafeAnchorClient.findSlot(mc, s -> s.isOf(Items.MACE)) == -1) {
                warn(mc, "§cKhong co mace tren hotbar!");
            } else {
                strike = true;
            }
        }

        // ---------- PHA LAO XUONG + DANH ----------
        if (strike) {
            jump(mc, false);
            if (cfg.maceSwapChest && swapCd <= 0 && !chestHasPlate(p)) {
                swapCd = equipChestplate(mc) ? 10 : 40;
            }
            aim(p, tc, -90f, 90f);
            move(mc, true);
            if (reach <= 2.8 && p.getAttackCooldownProgress(0.5f) >= 1.0f && (p.fallDistance > 1.5 || ground)) {
                attack(mc);
            }
            if (ground && reach > 4.5) strike = false; // da xuong dat ma doi thu chay xa -> bay lai
            return;
        }

        // ---------- PHA BAY ----------
        move(mc, false);

        if (!chestIsElytra(p)) {
            jump(mc, false);
            if (swapCd <= 0) {
                if (equip(mc, s -> s.isOf(Items.ELYTRA))) swapCd = 10;
                else { warn(mc, "§cKhong co elytra!"); swapCd = 40; }
            }
            return;
        }

        if (!glide) {
            // tren dat: nhay; tren khong: nha/nhan lai phim nhay de vanilla bat luot
            if (ground) jump(mc, true);
            else jump(mc, tick % 6 == 0);
            return;
        }

        jump(mc, false);
        Vec3d hover = new Vec3d(tc.x, target.getY() + cfg.maceHover, tc.z);
        boolean needHeight = horiz > cfg.maceDiveDist || !above;
        if (needHeight) aim(p, hover, -55f, 30f);
        else aim(p, tc, -90f, 90f);

        double speed = p.getVelocity().length();
        if (rocketCd <= 0 && speed < 1.1 && needHeight) {
            if (rocket(mc)) rocketCd = 25;
            else { warn(mc, "§eHet firework!"); rocketCd = 40; }
        }
    }

    // ================== HELPERS ==================

    private static void stop(MinecraftClient mc) {
        active = false;
        strike = false;
        target = null;
        releaseKeys(mc);
        if (mc.player != null) SafeAnchorClient.msg(mc, "§cAuto Mace: OFF");
    }

    private static boolean valid(ClientPlayerEntity p, PlayerEntity t, double range) {
        return t.isAlive() && !t.isRemoved() && !t.isSpectator() && t.getHealth() > 0
                && p.distanceTo(t) <= range * 1.5;
    }

    private static PlayerEntity findTarget(MinecraftClient mc, double range) {
        PlayerEntity best = null;
        double bestD = range;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || o.isSpectator() || !o.isAlive()) continue;
            double d = mc.player.distanceTo(o);
            if (d <= bestD) { bestD = d; best = o; }
        }
        return best;
    }

    /** Dang luot elytra? (so ten pose de khong phu thuoc ten ham theo ban mapping) */
    private static boolean gliding(ClientPlayerEntity p) {
        String n = p.getPose().name();
        return n.equals("GLIDING") || n.equals("FALL_FLYING");
    }

    private static boolean chestIsElytra(ClientPlayerEntity p) {
        return p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private static boolean chestHasPlate(ClientPlayerEntity p) {
        ItemStack s = p.getEquippedStack(EquipmentSlot.CHEST);
        for (Item it : CHESTPLATES) if (s.isOf(it)) return true;
        return false;
    }

    private static boolean equipChestplate(MinecraftClient mc) {
        for (Item it : CHESTPLATES) {
            if (equip(mc, s -> s.isOf(it))) return true;
        }
        return false;
    }

    /** Doi do trong tui voi o giap nguc (slot 6) bang 3 lan click: nhat - dat - tra lai. */
    private static boolean equip(MinecraftClient mc, Predicate<ItemStack> want) {
        var inv = mc.player.getInventory();
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && want.test(s)) { idx = i; break; }
        }
        if (idx == -1) return false;
        int src = idx < 9 ? 36 + idx : idx;
        int sync = mc.player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, 6, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, mc.player);
        return true;
    }

    private static boolean rocket(MinecraftClient mc) {
        int slot = SafeAnchorClient.findSlot(mc, s -> s.isOf(Items.FIREWORK_ROCKET));
        if (slot == -1) return false;
        var inv = mc.player.getInventory();
        int prev = inv.selectedSlot;
        inv.selectedSlot = slot;
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        inv.selectedSlot = prev;
        return true;
    }

    private static void attack(MinecraftClient mc) {
        int slot = SafeAnchorClient.findSlot(mc, s -> s.isOf(Items.MACE));
        if (slot == -1) { warn(mc, "§cKhong co mace tren hotbar!"); return; }
        var inv = mc.player.getInventory();
        int prev = inv.selectedSlot;
        inv.selectedSlot = slot;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        inv.selectedSlot = prev;
    }

    private static void aim(ClientPlayerEntity p, Vec3d to, float minPitch, float maxPitch) {
        Vec3d eye = p.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, minPitch, maxPitch));
    }

    private static double distToBox(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.distanceTo(new Vec3d(x, y, z));
    }

    private static void jump(MinecraftClient mc, boolean on) {
        if (jmp == on) return;
        mc.options.jumpKey.setPressed(on);
        jmp = on;
        if (!on) KeyBinding.updatePressedStates();
    }

    private static void move(MinecraftClient mc, boolean on) {
        if (fwd == on) return;
        mc.options.forwardKey.setPressed(on);
        mc.options.sprintKey.setPressed(on);
        fwd = on;
        if (!on) KeyBinding.updatePressedStates();
    }

    private static void releaseKeys(MinecraftClient mc) {
        jump(mc, false);
        move(mc, false);
    }

    private static void warn(MinecraftClient mc, String text) {
        if (warnCd > 0) return;
        SafeAnchorClient.msg(mc, text);
        warnCd = 60;
    }
}
